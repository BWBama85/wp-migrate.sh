-- Jetpack test database (wp_options table)
CREATE TABLE wp_options (
  option_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  option_name varchar(191) NOT NULL DEFAULT '',
  option_value longtext NOT NULL,
  PRIMARY KEY (option_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO wp_options (option_name, option_value) VALUES
('siteurl', 'http://test.example.com'),
('home', 'http://test.example.com');
