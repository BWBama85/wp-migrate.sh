<?php
/**
 * Minimal Duplicator installer stub for testing
 * This is just a signature file to make the archive validate as Duplicator format
 */
echo "Duplicator Test Archive - Do Not Use for Real Migration";
