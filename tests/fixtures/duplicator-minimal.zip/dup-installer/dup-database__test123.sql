-- Minimal Duplicator test database
-- This is just a stub to satisfy format detection

CREATE TABLE IF NOT EXISTS wp_options (
  option_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  option_name varchar(191) NOT NULL DEFAULT '',
  option_value longtext NOT NULL,
  PRIMARY KEY (option_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO wp_options (option_name, option_value) VALUES
('siteurl', 'http://test.example.com'),
('home', 'http://test.example.com');
